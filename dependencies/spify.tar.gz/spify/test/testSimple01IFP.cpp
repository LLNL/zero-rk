
#include "Simple01IFP.h"

int main(int argc, char **argv)
{
    Simple01IFP parser(argv[1]);
    return 0;
}
