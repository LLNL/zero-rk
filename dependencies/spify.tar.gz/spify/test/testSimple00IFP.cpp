
#include "Simple00IFP.h"

int main(int argc, char **argv)
{
    Simple00IFP parser(argv[1]);
    return 0;
}
