
#include "ExampleIFP.h"

//See README for details on implementing new parser.

ExampleIFP::ExampleIFP(const std::string& fileName)
: spify::parser(fileName)
{
    addParameter
    (
        (new spify::scalar_param<bool>("boolOption"))
        ->defaultValue(0)
        ->shortDesc("My Boolean Option")  
    ); 
    
    std::vector<bool> boolVectOption_defv;
    boolVectOption_defv.push_back(1);
    boolVectOption_defv.push_back(0);
    boolVectOption_defv.push_back(1);
    boolVectOption_defv.push_back(0);
    addParameter
    (
        (new spify::vector_param<bool>("boolVectOption"))
        ->shortDesc("A vector of booleans.")
        ->defaultValue(boolVectOption_defv)  
    ); 
    
    std::vector<int> intOption_disv;
    intOption_disv.push_back(0);
    intOption_disv.push_back(1);
    intOption_disv.push_back(3);
    intOption_disv.push_back(5);
    intOption_disv.push_back(7);
    addParameter
    (
        (new spify::scalar_param<int>("intOption"))
        ->longDesc("Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor"
"incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis"
"nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu"
"fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in"
"culpa qui officia deserunt mollit anim id est laborum.")
        ->discreteValues(intOption_disv)  
    ); 
    
    std::vector<int> intVectOption_defv;
    intVectOption_defv.push_back(-3);
    intVectOption_defv.push_back(-2);
    intVectOption_defv.push_back(-1);
    intVectOption_defv.push_back(0);
    addParameter
    (
        (new spify::vector_param<int>("intVectOption"))
        ->boundMax(10)
        ->boundMin(-10)
        ->shortDesc("My Integer Vector Option.")
        ->defaultValue(intVectOption_defv)  
    ); 
    
    addParameter
    (
        (new spify::scalar_param<double>("floatOption"))
        ->defaultValue(300.0)
        ->boundMax(300.0)  
    ); 
    
    addParameter
    (
        (new spify::vector_param<double>("floatVectOption"))
        ->boundMax(100.0)
        ->boundMin(0.0)  
    ); 
    
    std::vector<std::string> stringOption_disv;
    stringOption_disv.push_back("foo");
    stringOption_disv.push_back("bar");
    stringOption_disv.push_back("baz");
    addParameter
    (
        (new spify::scalar_param<std::string>("stringOption"))
        ->defaultValue("foo")
        ->discreteValues(stringOption_disv)  
    ); 
    
    addParameter
    (
        (new spify::vector_param<std::string>("stringVectOption"))
        ->shortDesc("My String Vector Option")  
    ); 
    
    std::vector<int> intIntMapOption_disv1;
    intIntMapOption_disv1.push_back(1);
    intIntMapOption_disv1.push_back(2);
    intIntMapOption_disv1.push_back(4);
    intIntMapOption_disv1.push_back(6);
    addParameter
    (
        (new spify::map_param<int,int>("intIntMapOption"))
        ->shortDesc("My Integer-Integer Map Option")
        ->discreteValuesFirst(intIntMapOption_disv1)  
    ); 

    std::map<std::string,int> stringIntMapOption_defv;
    stringIntMapOption_defv["foo"] = 1;
    stringIntMapOption_defv["bar"] = 2;
    addParameter
    (
        (new spify::map_param<std::string,int>("stringIntMapOption"))
        ->defaultValue(stringIntMapOption_defv)  
    ); 

    std::vector<std::string> stringStringMapOption_disv2;
    stringStringMapOption_disv2.push_back("parrot");
    stringStringMapOption_disv2.push_back("buzzard");
    stringStringMapOption_disv2.push_back("eagle");
    std::vector<std::string> stringStringMapOption_disv1;
    stringStringMapOption_disv1.push_back("foo");
    stringStringMapOption_disv1.push_back("bar");
    stringStringMapOption_disv1.push_back("baz");
    addParameter
    (
        (new spify::map_param<std::string,std::string>("stringStringMapOption"))
        ->discreteValuesFirst(stringStringMapOption_disv1)
        ->discreteValuesSecond(stringStringMapOption_disv2)  
    ); 

    std::map<double,double> floatFloatMapOption_defv;
    floatFloatMapOption_defv[1.0] = 10.0;
    floatFloatMapOption_defv[2.0] = 20.0;
    floatFloatMapOption_defv[3.0] = 30.0;
    addParameter
    (
        (new spify::map_param<double,double>("floatFloatMapOption"))
        ->defaultValue(floatFloatMapOption_defv)  
    ); 

    validateParameters();

    //Assign values to member data.
    get("boolOption",m_boolOption);
    get("boolVectOption",m_boolVectOption);
    get("intOption",m_intOption);
    get("intVectOption",m_intVectOption);
    get("floatOption",m_floatOption);
    get("floatVectOption",m_floatVectOption);
    get("stringOption",m_stringOption);
    get("stringVectOption",m_stringVectOption);
    get("intIntMapOption",m_intIntMapOption);
    get("stringIntMapOption",m_stringIntMapOption);
    get("stringStringMapOption",m_stringStringMapOption);
    get("floatFloatMapOption",m_floatFloatMapOption);

}

const bool& ExampleIFP::boolOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"boolOption\" before validation."));
    }
    return m_boolOption;
}

const std::vector<bool>& ExampleIFP::boolVectOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"boolVectOption\" before validation."));
    }
    return m_boolVectOption;
}

const int& ExampleIFP::intOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"intOption\" before validation."));
    }
    return m_intOption;
}

const std::vector<int>& ExampleIFP::intVectOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"intVectOption\" before validation."));
    }
    return m_intVectOption;
}

const double& ExampleIFP::floatOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"floatOption\" before validation."));
    }
    return m_floatOption;
}

const std::vector<double>& ExampleIFP::floatVectOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"floatVectOption\" before validation."));
    }
    return m_floatVectOption;
}

const std::string& ExampleIFP::stringOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"stringOption\" before validation."));
    }
    return m_stringOption;
}

const std::vector<std::string>& ExampleIFP::stringVectOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"stringVectOption\" before validation."));
    }
    return m_stringVectOption;
}

const std::map<int,int>& ExampleIFP::intIntMapOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"intIntMapOption\" before validation."));
    }
    return m_intIntMapOption;
}

const std::map<std::string,int>& ExampleIFP::stringIntMapOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"stringIntMapOption\" before validation."));
    }
    return m_stringIntMapOption;
}

const std::map<std::string,std::string>& ExampleIFP::stringStringMapOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"stringStringMapOption\" before validation."));
    }
    return m_stringStringMapOption;
}

const std::map<double,double>& ExampleIFP::floatFloatMapOption() const
{
    if(!m_parametersValidated)
    {
       throw(std::logic_error("ExampleIFP: attempted to access parameter "
                             "\"floatFloatMapOption\" before validation."));
    }
    return m_floatFloatMapOption;
}




#ifdef EXAMPLEIFP_MAKEMASTER
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    FILE * tmpFile;
    char tmpFileName[32];

    memset(tmpFileName,0,sizeof(tmpFileName));
    strncpy(tmpFileName,"ymlfXXXXXX",10);
    mkstemp(tmpFileName);
    tmpFile = fopen(tmpFileName,"w");
    fprintf(tmpFile,"printMasterFileTo: ExampleIFPMaster.yml\n");
    fclose(tmpFile);

    try //This will fail.
    {
        ExampleIFP inputData(tmpFileName);
    }
    catch (...)
    {
        remove(tmpFileName);
    }
    return(0);
}
#endif

