
//spify Example:
//
//  See README and appExampleIFP.cpp for
//  details.
//
//  The structure of this file should not require
//  modification.  Only the name of the class.

#ifndef ExampleIFP_H
#define ExampleIFP_H

#include "spify/spify.h"

class ExampleIFP : public spify::parser
{
    public:
        ExampleIFP(const std::string& fileName);
        ~ExampleIFP(){};
    private:
        ExampleIFP(); //disallow default constructor
    public:
        const bool& boolOption() const;
        const std::vector<bool>& boolVectOption() const;
        const int& intOption() const;
        const std::vector<int>& intVectOption() const;
        const double& floatOption() const;
        const std::vector<double>& floatVectOption() const;
        const std::string& stringOption() const;
        const std::vector<std::string>& stringVectOption() const;
        const std::map<int,int>& intIntMapOption() const;
        const std::map<std::string,int>& stringIntMapOption() const;
        const std::map<std::string,std::string>& stringStringMapOption() const;
        const std::map<double,double>& floatFloatMapOption() const;

    private:
        bool m_boolOption;
        std::vector<bool> m_boolVectOption;
        int m_intOption;
        std::vector<int> m_intVectOption;
        double m_floatOption;
        std::vector<double> m_floatVectOption;
        std::string m_stringOption;
        std::vector<std::string> m_stringVectOption;
        std::map<int,int> m_intIntMapOption;
        std::map<std::string,int> m_stringIntMapOption;
        std::map<std::string,std::string> m_stringStringMapOption;
        std::map<double,double> m_floatFloatMapOption;

};

#endif
